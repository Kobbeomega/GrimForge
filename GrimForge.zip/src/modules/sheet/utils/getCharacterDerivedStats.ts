import {
  getAbilityModifier,
  getProficiencyBonus,
  getSkillBonus,
} from "../../../compendium/core";

import {
  getEquipmentById,
} from "../../../compendium/equipment";

import type {
  ArmorItem,
} from "../../../compendium/equipment";

import type {
  CharacterArchiveEntry,
  CharacterInventory,
} from "../../archives/types";

import {
  getPassiveScores,
} from "./getPassiveScores";

import {
  getSpellcastingStats,
} from "./getSpellcastingStats";

import {
  getEquippedWeaponAttacks,
} from "./getWeaponAttack";

import type {
  WeaponAttackSummary,
} from "./getWeaponAttack";

export interface CharacterDerivedStats {
  armorClass: number;

  /**
   * Bleibt aus Kompatibilitätsgründen bestehen.
   * Der Wert entspricht passiveScores.perception.
   */
  passivePerception: number;

  passiveScores:
    ReturnType<
      typeof getPassiveScores
    >;

  proficiencyBonus: number;

  totalWeight: number;
  carryingCapacity: number;
  carryingPercentage: number;

  equippedWeapons:
    WeaponAttackSummary[];

  spellcasting:
    ReturnType<
      typeof getSpellcastingStats
    >;
}

export function getCharacterDerivedStats(
  character: CharacterArchiveEntry,
  inventory: CharacterInventory,
): CharacterDerivedStats {
  const strength =
    character.abilityScores
      ?.strength ?? 10;

  const dexterity =
    character.abilityScores
      ?.dexterity ?? 10;

  const wisdom =
    character.abilityScores
      ?.wisdom ?? 10;

  const dexterityModifier =
    getAbilityModifier(
      dexterity,
    );

  const wisdomModifier =
    getAbilityModifier(
      wisdom,
    );

  const proficiencyBonus =
    getProficiencyBonus(
      character.level,
    );

  /*
   * Dieser Einzelwert bleibt erhalten,
   * damit bestehende Komponenten weiterhin
   * derivedStats.passivePerception verwenden
   * können.
   */
  const loreSkills = normalizeLoreSkills(character);
  const perceptionProficient =
    (character.skillProficiencies?.includes("perception") ?? false) || loreSkills.includes("perception");

  const perceptionExpertise =
    character
      .skillExpertise
      ?.includes(
        "perception",
      ) ?? false;

  const passivePerception =
    10 +
    getSkillBonus({
      abilityModifier:
        wisdomModifier,

      proficiencyBonus,

      proficient:
        perceptionProficient,

      expertise:
        perceptionExpertise,
    });

  const passiveScores =
    getPassiveScores(
      character,
    );

  const equippedArmorPresent = inventory.items.some((item) => item.equipped && item.quantity > 0 && item.category === "armor" && getEquipmentById(item.id)?.category === "armor");
  const normalArmorClass = calculateArmorClass(inventory, dexterityModifier);
  const fightingStyle = character.pathChoices?.[`${character.classId}-fighting-style`];
  const defenseBonus = equippedArmorPresent && fightingStyle === "defense" ? 1 : 0;
  const armorClass =
    (character.classId === "sorcerer" && character.subclassId === "draconic-bloodline" && !equippedArmorPresent
      ? Math.max(normalArmorClass, 13 + dexterityModifier)
      : normalArmorClass) + defenseBonus;

  const totalWeight =
    inventory.items.reduce(
      (
        sum,
        item,
      ) =>
        sum +
        item.weight *
          Math.max(
            0,
            item.quantity,
          ),
      0,
    );

  /*
   * Klassische D&D-Traglast:
   *
   * Stärke × 15 Pfund.
   *
   * Da das Inventar in Kilogramm arbeitet,
   * wird das Ergebnis anschließend umgerechnet.
   */
  const carryingCapacity =
    poundsToKilograms(
      Math.max(
        1,
        strength,
      ) * 15,
    );

  const carryingPercentage =
    carryingCapacity > 0
      ? Math.min(
          999,
          (
            totalWeight /
            carryingCapacity
          ) * 100,
        )
      : 0;

  const equippedWeapons =
    getEquippedWeaponAttacks(
      character,
      inventory,
    );

  const spellcasting =
    getSpellcastingStats(
      character,
    );

  return {
    armorClass,

    passivePerception,

    passiveScores,

    proficiencyBonus,

    totalWeight,
    carryingCapacity,
    carryingPercentage,

    equippedWeapons,

    spellcasting,
  };
}

function calculateArmorClass(
  inventory: CharacterInventory,
  dexterityModifier: number,
): number {
  const equippedDefinitions =
    inventory.items.flatMap(
      (inventoryItem) => {
        if (
          !inventoryItem.equipped ||
          inventoryItem.quantity <= 0 ||
          inventoryItem.category !==
            "armor"
        ) {
          return [];
        }

        const definition =
          getEquipmentById(
            inventoryItem.id,
          );

        if (
          !definition ||
          (
            definition.category !==
              "armor" &&
            definition.category !==
              "shield"
          )
        ) {
          return [];
        }

        return [
          definition,
        ];
      },
    );

  const equippedArmor =
    equippedDefinitions.find(
      (definition) =>
        definition.category ===
        "armor",
    );

  const equippedShields =
    equippedDefinitions.filter(
      (definition) =>
        definition.category ===
        "shield",
    );

  const baseArmorClass =
    equippedArmor
      ? getArmorClassFromArmor(
          equippedArmor,
          dexterityModifier,
        )
      : 10 +
        dexterityModifier;

  const shieldBonus =
    equippedShields.reduce(
      (
        sum,
        shield,
      ) =>
        sum +
        shield.armorClass,
      0,
    );

  return Math.max(
    0,
    baseArmorClass +
      shieldBonus,
  );
}

function getArmorClassFromArmor(
  armor: ArmorItem,
  dexterityModifier: number,
): number {
  if (
    armor.category ===
    "shield"
  ) {
    return armor.armorClass;
  }

  if (
    !armor.dexterityModifier
  ) {
    return armor.armorClass;
  }

  const dexterityBonus =
    typeof armor
      .maximumDexterityBonus ===
      "number"
      ? Math.min(
          dexterityModifier,
          armor
            .maximumDexterityBonus,
        )
      : dexterityModifier;

  return (
    armor.armorClass +
    dexterityBonus
  );
}

function poundsToKilograms(
  pounds: number,
): number {
  return Number(
    (
      pounds *
      0.45359237
    ).toFixed(2),
  );
}

function normalizeLoreSkills(character: CharacterArchiveEntry): string[] {
  if (character.classId !== "bard" || character.subclassId !== "college-of-lore" || character.level < 3) return [];
  const raw = character.pathChoices?.["lore-bonus-skills"];
  return Array.isArray(raw) ? raw : raw ? [raw] : [];
}
